
    <footer class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-12 pad-0">
                    <div class="footer-menu d-lg-flex justify-content-between">
                        <div class="col-lg-8 col-12 pad-0">
                            <ul class="d-lg-flex">
                                <li><a href="#"class="color-green">গোপনীয়তার নীতিমালা</a></li>
                                <li><a href="#"class="color-cyan">ব্যবহারের শর্তাবলি</a></li>
                                <li><a href="#"class="color-purple">সার্বিক সহযোগিতায়</a></li>
                                <li><a href="#"class="color-red">সাইট ম্যাপ</a></li>
                                <li><a href="#"class="color-magenta">সচরাচর জিজ্ঞাসা</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="right-text">
                                <p>পরিকল্পনা ও বাস্তবায়নে:<a href="main.html">ঢাকা মহানগর দক্ষিণ আওয়ামী লীগ </a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="d-lg-flex justify-content-between bottom-footer">
                        <p>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: <span>২০২১-০২-১৮ ০৬:০৩:০৫</span></p>
                        <span> কারিগরি সহায়তায়: <a href="https://bitbirds.com/">bitBirds Solutions</a></span>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>