// jQuery(document).ready(function () {
//     jQuery('section nav').meanmenu();
// });

// jQuery(document).ready(function () {
//     function bigImg(x) {

//     x.style.height = "64px";
//     x.style.width = "64px";
//     }

//     function normalImg(x) {
//     x.style.height = "32px";
//     x.style.width = "32px";
//     }
// });